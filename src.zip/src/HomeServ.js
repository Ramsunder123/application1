import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Dropdown from './Dropdown';

const HomeServ = () => {
  const { navigate } = useNavigation();
  const [selectedService, setSelectedService] = useState(null);
  const [buttonNames, setButtonNames] = useState([]);

  const handleButtonPress = (service, names) => {
    setSelectedService(service);
    setButtonNames(names);
  };

  const handleButtonClick = (buttonIndex) => {
    if (selectedService) {
      const selectedPerson = buttonNames[buttonIndex];
      console.log(`Button ${buttonIndex} clicked for ${selectedService}: ${selectedPerson}`);
      const pageMapping = {
        'Electrical': 'Electricians',
        'Plumbing': 'Plumbers',
        'Appliance Repair': 'Appliance',
        'Service': 'Service',
        'Auto Service': 'Auto',
        'Construction': 'Constructors',
        'Others': 'Others',
        // Add other service mappings as needed
      };
      const destinationPage = pageMapping[selectedService];
      navigate(destinationPage, { [`${selectedService.toLowerCase()}Person`]: selectedPerson || 'Undefined Person' });
    }
  };

  return (
    <ImageBackground
      source={require('../assets/page.png')}
      style={styles.container}
    >
      <SafeAreaView style={styles.overlay}>
        <Text style={styles.text}>{selectedService || 'Select a service'}</Text>

        <View style={styles.buttonContainer}>
          {[
            { service: 'Electrical', names: ['Person1', 'Person2', 'Person3', 'Person4', 'Person5'] },
            { service: 'Plumbing', names: ['Person6', 'Person7', 'Person8', 'Person9', 'Person10'] },
            { service: 'Appliance Repair', names: ['Person11', 'Person12', 'Person13', 'Person14', 'Person15'] },
            { service: 'Service', names: ['Person16', 'Person17', 'Person18', 'Person19', 'Person20'] },
            { service: 'Auto Service', names: ['Person21', 'Person22', 'Person23', 'Person24', 'Person25'] },
            { service: 'Construction', names: ['Person26', 'Person27', 'Person28', 'Person29', 'Person30'] },
            { service: 'Others', names: ['Person31', 'Person32', 'Person33', 'Person34', 'Person35'] },
          ].map(({ service, names }, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.button, { left: 0.25, top: 50 + index * 75 }]}
              onPress={() => handleButtonPress(service, names)}
            >
              <Text style={styles.buttonText}>{service}</Text>
            </TouchableOpacity>
          ))}

          {selectedService && (
            <Dropdown
              service={selectedService}
              buttonWidth={100}
              dropdownWidth={200}
              rightOffset={0.25}
              onButtonClick={handleButtonClick}
              buttonNames={buttonNames}
              screenWidth={0.25}
            />
          )}
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0)',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  buttonContainer: {
    position: 'relative',
    marginTop: 20,
  },
  button: {
    position: 'absolute',
    width: 150,
    height: 30,
    backgroundColor: '#FFFF00',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: 'black',
    fontFamily: 'Poppins-Medium',
  },
  buttonText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default HomeServ;
