import React, { useState } from 'react';
import { View, ImageBackground, Image, TextInput, StyleSheet, Dimensions, TouchableOpacity, Text, Modal, Pressable } from 'react-native';
import { AirbnbRating } from 'react-native-ratings';
import { useRoute, useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Linking } from 'react-native';

const Appliance = () => {
  const route = useRoute();
  const { technician } = route.params;
  const screenWidth = Dimensions.get('window').width;
  const technicianImage = require('../../assets/profile.jpg');
  const { goBack } = useNavigation();

  const [rating, setRating] = useState(0);
  const [numberOfWorks, setNumberOfWorks] = useState('');
  const [experience, setExperience] = useState('');
  const [phoneNumber, setPhoneNumber] = useState(''); // Default to '+91'
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleNumberOfWorksChange = (inputValue) => {
    if (/^\d+$/.test(inputValue) || inputValue === '') {
      setNumberOfWorks(inputValue);
    }
  };

  const handleExperienceChange = (inputValue) => {
    setExperience(inputValue);
  };

  const handleCallPress = () => {
    setIsModalVisible(true);
  };

  const handleBackPress = () => {
    setIsModalVisible(false);
  };

  const handleConfirmCall = () => {
    // Add "+91" to the beginning of the phone number
    const phoneNumberWithPrefix = `+91${phoneNumber}`;
  
    // Construct the phone number with the 'tel:' prefix
    const phoneNumberWithTel = `tel:${phoneNumberWithPrefix}`;
  
    // Open the phone app
    Linking.openURL(phoneNumberWithTel)
      .then(() => {
        // Success: The phone app is opened
        console.log('Phone app opened successfully');
      })
      .catch((error) => {
        // Error: Unable to open the phone app
        console.error('Error opening phone app:', error);
      });
  
    // Hide the modal
    setIsModalVisible(false);
  };  
  
  const navigateToHomeServ = () => {
    goBack(); // Go back to the previous screen
  };

  return (
    <ImageBackground
      source={require('../../assets/gradient.png')}
      style={styles.container}
    >
      <View>
        <View style={styles.profileImageContainer}>
          <Image source={technicianImage} style={styles.profileImage} />
        </View>
        <Text style={styles.text}>{`${technician}`}</Text>
        <Text style={styles.labelText}>Number of{'\n'}Works:</Text>
        <Text style={[styles.labelText, { textAlign: 'right', position: 'absolute', top: 200, right: 20 }]}>Experience:</Text>
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Number of Works"
          keyboardType="numeric"
          value={numberOfWorks}
          onChangeText={handleNumberOfWorksChange}
        />
        <TextInput
          style={styles.input}
          placeholder="Experience"
          keyboardType="numeric"
          value={experience}
          onChangeText={handleExperienceChange}
        />
      </View>

        {/* Rating */}
        <View style={styles.ratingContainer}>
          <AirbnbRating
            count={5}
            defaultRating={rating}
            size={20}
            onFinishRating={setRating}
            showRating={false} // Hide reviews
            style={{ alignSelf: 'center', marginTop: 'auto', marginBottom: -140 }}
          />
        </View>
        {/* "Call" button with icon */}
        <TouchableOpacity style={[styles.buttonContainer, {}]}>
          {/* "Call" button with icon */}
          <TouchableOpacity onPress={handleCallPress} style={styles.callButton}>
            <Icon name="phone" size={20} color="white" style={styles.icon} />
            <Text style={styles.callButtonText}>Call</Text>
          </TouchableOpacity>

          {/* "Go back" button */}
          <TouchableOpacity onPress={navigateToHomeServ} style={[styles.navigateToHomeServButton, {}]}>
            <Icon name="arrow-left" size={20} color="white" style={styles.icon} />
            <Text style={styles.navigateToHomeServButtonText}>Go back</Text>
          </TouchableOpacity>
        </TouchableOpacity>

        {/* Pop-up Modal */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={isModalVisible}
          onRequestClose={() => {
            setIsModalVisible(!isModalVisible);
          }}
        >
          <View style={styles.modalContent}>
            <Text style={styles.modalText}>Name: {`${technician}`}</Text>
            <Text style={styles.modalText}>Phone Number:</Text>
            <View style={styles.phoneNumberContainer}>
              <Text style={styles.countryCode}>+91</Text>
              <TextInput
                style={styles.modalInput}
                keyboardType="numeric"
                value={phoneNumber}
                onChangeText={(text) => {
                  const numericValue = text.replace(/[^0-9]/g, '');
                  const limitedValue = numericValue.slice(0, 10);
                  setPhoneNumber(limitedValue);
                }}
              />
            </View>
            <View style={styles.modalButtonsContainer}>
              <Pressable style={styles.modalButton} onPress={handleConfirmCall}>
                <Text style={styles.modalButtonText}>Confirm Call</Text>
              </Pressable>
              <Pressable style={styles.modalButton} onPress={handleBackPress}>
                <Text style={styles.modalButtonText}>Back</Text>
              </Pressable>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  inputRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20, // Adjust padding as needed
    width: '100%',
  },
  input: {
    borderWidth: 1,
    borderColor: 'black',
    height: 40,
    width: '48%', // Adjust width as needed
    marginBottom: 10,
    paddingHorizontal: 0,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 0, // Adjust margin as needed
  },
  container: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  profileImageContainer: {
    alignItems: 'center',
    marginTop: 10,
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 1,
    borderColor: 'black',
  },
  text: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 15,
  },
  labelText: {
    color: 'black',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'left',
    marginTop: 2,
  },
  ratingContainer: {
    marginTop: 'auto',
    marginBottom: 50,
  },

  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: -110,
    width: '100%',
  },
  callButton: {
    backgroundColor: 'green',
    padding: 10,
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  callButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  navigateToHomeServButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  navigateToHomeServButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  icon: {
    marginRight: 5,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  modalPhoneNumber: {
    fontSize: 16,
    marginBottom: 20,
  },
  modalButton: {
    backgroundColor: 'green',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    width: 150,
    alignItems: 'center',
  },
  modalButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  phoneNumberContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  countryCode: {
    marginRight: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalInput: {
    borderWidth: 1,
    borderColor: 'black',
    height: 40,
    width: 155, // Adjust the width as needed
    paddingHorizontal: 10,
  },  
});

export default Appliance;
